<?php

Route::get('/', function() {
    return view('welcome');
});
//Route::get('/', 'HomeController@index');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/login', 'ConsumerLoginController@login')->name('login');
Route::post('/logout', 'ConsumerLoginController@logout')->name('logout');
Route::get('/login-callback', 'ConsumerLoginController@loginCallback');
Route::get('/logout-callback', 'ConsumerLoginController@logoutCallback');