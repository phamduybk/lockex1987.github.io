<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <h3 class="text-success">Passport clients</h3>
    <div class="mb-3">
        <passport-clients></passport-clients>
    </div>
    
    <h3 class="text-info">Authorized clients</h3>
    <div class="mb-3">
        <passport-authorized-clients></passport-authorized-clients>
    </div>

    <h3 class="text-danger">Personal Access Tokens</h3>
    <div class="mb-3">
        <passport-personal-access-tokens></passport-personal-access-tokens>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>