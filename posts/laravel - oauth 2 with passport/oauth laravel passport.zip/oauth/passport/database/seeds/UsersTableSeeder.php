<?php

use Illuminate\Database\Seeder;
use App\User as User;


class UsersTableSeeder extends Seeder {

    public function run() {
        User::create([
            'name' => 'lockex1987',
            'email' => 'lockex1987@gmail.com',
            'password' => Hash::make('123456')
        ]);
    }
}
