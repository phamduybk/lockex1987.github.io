<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use Socialite;


class FacebookAuthController extends Controller {

    public function redirectToProvider() {
        return Socialite::driver('facebook')->redirect();
    }
 
    public function handleProviderCallback() {
        $facebookUser = Socialite::driver('facebook')->user();
        //info(print_r($facebookUser, true));
        $authUser = $this->findOrCreateUser($facebookUser);
        Auth::login($authUser, true);
        return redirect('/home');
    }
 
    private function findOrCreateUser($facebookUser) {
        $authUser = User::where('provider_id', $facebookUser->id)->first();
        if ($authUser) {
            return $authUser;
        }
        return User::create([
            'name' => $facebookUser->getName(), //$facebookUser->getNickname(),
            'full_name' => $facebookUser->getName(),
            //'password' => $facebookUser->token,
            'email' => $facebookUser->getEmail(),
            'avatar' => $facebookUser->getAvatar(),
            'provider_id' => $facebookUser->getId(),
            'provider' => 'facebook',
        ]);
    }
}
