A Pen created at CodePen.io. You can find this one at https://codepen.io/CreativeJuiz/pen/BiHzp.

 Animated custom checkboxes using gracefull degradation (display classical checkboxes on old browsers).

See new update : http://codepen.io/CreativeJuiz/pen/zqKtp