A Pen created at CodePen.io. You can find this one at https://codepen.io/theigmo87/pen/cwHyK.

 CSS3 animated (except IE9) checkbox that can be used as a class on a label for a checkbox (to manipulate the value of the checkbox) or can be used as a class on a standalone element, and toggled by adding a class via javascript.