A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/zjarZO.

 See https://github.com/tamino-martinius/ui-snippets-checkboxes for Source Files build with webpack
See https://github.com/tamino-martinius/ui-snippets-template for Snippet Template