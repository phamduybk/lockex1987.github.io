A Pen created at CodePen.io. You can find this one at https://codepen.io/dylanraga/pen/Qwqbab.

 neat little checkboxes with pleasing svg-less animation