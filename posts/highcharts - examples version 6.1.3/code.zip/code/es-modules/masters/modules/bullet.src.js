/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Bullet graph series type for Highcharts
 *
 * (c) 2010-2017 Kacper Madej
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/bullet.src.js';
