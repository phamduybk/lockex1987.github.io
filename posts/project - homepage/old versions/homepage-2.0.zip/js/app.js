var app = angular.module(APP_NAME, [
	'ui.router',
	'oc.lazyLoad'
]);

app.config(function($stateProvider, $urlRouterProvider, $locationProvider) {
	
	var addState = function(menuItem) {
		$stateProvider
				.state(menuItem.url, {
					url: '/' + menuItem.url,
					templateUrl: 'partials/' + menuItem.templateUrl,
					controller: menuItem.controller,
					resolve: {
						lazyLoadControllerJsFile: function($ocLazyLoad) {
							return $ocLazyLoad.load("controllers/" + menuItem.controller + ".js");
						}
					}
				});
	}

	for (var i = 0; i < GLOBAL_MENUS.length; i++) {
		var m = GLOBAL_MENUS[i];
		// Infamous loop issue
		addState(m);
	}

	$urlRouterProvider.otherwise('/websites');

	// Use HTML5 mode for nice URLs
	// You need to config the server too
	//$locationProvider.html5Mode(true);
});

app.run(function($state, $rootScope) {
	$rootScope.$state = $state;
	$rootScope.menus = GLOBAL_MENUS;
});
