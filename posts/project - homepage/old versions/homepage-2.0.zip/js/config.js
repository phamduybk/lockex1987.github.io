const GLOBAL_MENUS = [
	{ url: "websites", name: "Websites & Note", icon: "fa-home", templateUrl: "websites.html", controller: "WebsitesController", bg: "#00D1B2" },
	{ url: "motorbike-oil", name: "Motorbike Oil", icon: "fa-motorcycle", templateUrl: "motorbike-oil.html", controller: "MotorbikeOilController", bg: "#3273DC" },
	{ url: "todo", name: "Todo", icon: "fa-list", templateUrl: "todo.html", controller: "TodoController", bg: "#23D160" },
	{ url: "money", name: "Money Manager", icon: "fa-money", templateUrl: "money.html", controller: "MoneyController", bg: "#FFDD57" },
	{ url: "calendar", name: "Calendar", icon: "fa-calendar", templateUrl: "calendar.html", controller: "CalendarController", bg: "#FF3860" },
	{ url: "setting", name: "Setting", icon: "fa-cog", templateUrl: "setting.html", controller: "SettingController" },
	{ url: "alert", name: "Alert", icon: "fa-bell", warningNumber: 4, templateUrl: "alert.html", controller: "AlertController" }
];

const APP_NAME = "PrivateWebsites";
