const STORAGE_KEY = {
	NOTE: "note",
	LOCATION: "location"
};

const TODO = {
	PENDING: 1,
	IN_PROGRESS: 2,
	COMPLETED: 3
};

