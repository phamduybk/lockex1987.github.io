angular.module('PrivateWebsites', []).controller('SettingController', function($scope, $http) {
	
	/**
	 * Location: home or company
	 * If a website has location HOME, it will only appear in home's laptop
	 * If it has location COMPANY, it will only appear in company's PC
	 * It will appear in both places by default
	 */
	$scope.LOCATION = {
		HOME: 1,
		COMPANY: 2
	};

	$scope.changeLocation = function() {
		if ($scope.cbxLocation) {
			$scope.location = $scope.LOCATION.HOME;
		} else {
			$scope.location = $scope.LOCATION.COMPANY;
		}
		localStorage.setItem(STORAGE_KEY.LOCATION, $scope.location);
		//logger.success("Location setting is saved");
	};

	function getLocation() {
		var currentLocation = localStorage.getItem(STORAGE_KEY.LOCATION) || $scope.LOCATION.HOME;
		$scope.location = currentLocation;
		$scope.cbxLocation = (currentLocation == $scope.LOCATION.HOME);
	}

	
	
	// For other Controller to use
	function checkLocation(loc) {
		//console.log(currentLocation + " - " + loc);
		if (!currentLocation) {
			// If current location is not set, hide all websites
			return false;
		} else if (!loc) {
			// If the website's location is not set, the website is showed by default
			return true;
		} else if (currentLocation == loc) {
			// Only show websites that are equivalent to current location
			return true;
		} else {
			return false;
		}
	}
	
	function init() {
		getLocation();
	}

	init();
});
