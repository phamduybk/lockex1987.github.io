angular.module('PrivateWebsites', []).controller('MoneyController', function($scope, $http) {

	$scope.data;

	function warningNextMaintain() {
		
	}
	
	function init() {
		//getData();		
	}

	init();
});
