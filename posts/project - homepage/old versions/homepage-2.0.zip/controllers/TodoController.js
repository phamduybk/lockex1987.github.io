angular.module('PrivateWebsites', []).controller('TodoController', function($scope, $http) {

	$scope.products;

	$scope.addItem = function () {
			$scope.errortext = "";
			if (!$scope.addMe) {
					return;
			}
			if ($scope.products.indexOf($scope.addMe) == -1) {
					$scope.products.push($scope.addMe);
			} else {
					$scope.errortext = "The item is already in your shopping list.";
			}
	}

	$scope.removeItem = function (x) {
			$scope.errortext = "";
			$scope.products.splice(x, 1);
	}

	function mockProducts() {
		$scope.products = ["Milk", "Bread", "Cheese"]; 
	}
	
	function init() {
		mockProducts();
	}

	init();
});
