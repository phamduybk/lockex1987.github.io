angular.module('PrivateWebsites', []).controller('CalendarController', function($scope, $http) {

	$scope.data;

	function warningNextMaintain() {
		
	}
	
	function init() {
		//getData();		
	}

	init();
});
