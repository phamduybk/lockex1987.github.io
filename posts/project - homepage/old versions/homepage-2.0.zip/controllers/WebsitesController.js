angular.module(APP_NAME, []).controller('WebsitesController', function($scope, $http) {
	
	$scope.websites;
	$scope.noteEditor;
	
	$scope.saveNote = function() {
		localStorage.setItem(STORAGE_KEY.NOTE, $scope.noteEditor);
		//logger.success("Note saved");
		//alert("Note saved");
	};

	function displayWebsites() {
		$http.get("data/websites.json").then(function(resp) {
			// All data
			var a = resp.data;
						
			// Sort by URL (to remove duplicated websites)
			//a.sort(function(x, y) { return x.url.localeCompare(y.url); });
		
			// Remove disabled websites
			for (var i = a.length - 1; i >= 0; i--) {
				if (a[i].disabled
						//|| !settings.checkLocation(a[i].location)
						//|| !dayFilter.checkDay(a[i].day)
						) {
						a.splice(i, 1);
				}
			}

			$scope.websites = a;
		});
	}
	
	function bindOldNote() {
		$scope.noteEditor = localStorage.getItem(STORAGE_KEY.NOTE) || "";
	}
	
	function init() {
		displayWebsites();
		bindOldNote();
	}

	init();
});
