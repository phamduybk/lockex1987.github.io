angular.module('PrivateWebsites', []).controller('AlertController', function($scope, $http) {

	$scope.data;

	function warningNextMaintain() {
		
	}
	
	function init() {
		//getData();		
	}

	init();
});
