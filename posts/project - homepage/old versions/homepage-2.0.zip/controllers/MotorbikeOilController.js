angular.module('PrivateWebsites', []).controller('MotorbikeOilController', function($scope, $http) {

	$scope.data;

	function getData() {
		$http.get("data/motorbike-oil.json").then(function(resp) {
			processData(resp.data);
			warningNextMaintain();			
		});
	}

	function processData(a) {
		for (var i = 0; i < a.length; i++) {
			var e = a[i];
			e.date = converStringToDate(e.dateStr);

			if (i > 0) {
				var prev = a[i - 1];
				e.dateDiff = dateDiff(prev.date, e.date);
				e.kmDiff = e.km - prev.km;
			}
		}

		$scope.data = a;
	}

	function warningNextMaintain() {
		var last = $scope.data[$scope.data.length - 1];
		var nextDate = addDate(last.date, 60);
		var nextKm = last.km + 2000;
		var currentDate = new Date();
		// Khong duoc dat ten bien la dateDiff nua
		var dd = dateDiff(currentDate, nextDate);

		$scope.nextDate = convertDateToString(nextDate);
		$scope.dateDiff = dd;
		$scope.nextKm = nextKm;
	}
	
	function init() {
		getData();		
	}

	init();
});
