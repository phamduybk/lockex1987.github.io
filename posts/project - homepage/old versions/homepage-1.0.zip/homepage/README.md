# websites-manager

http://home.vn/

Cẩn thận khi xóa history của trình duyệt

NOT Bookmarks, NOT References

View, category (search)

Synchronize via Github

Make it the homepage

Tooltip description

The file in home laptop is the latest

Synchronize bookmarks with Firefox (if you have a different computer in another place like your company, and your company has Internet access).

Use bookmarks with temporary websites

Filter to focus

Change from bookmarks to documentation references (full references with description list). Write about your work carefully.

Ctrl+S

Lich ca nhan

Use Gulp to create one CSS file from multiple LESS files for production

Honorable mention websites:

* sallneed
* magazine3k
* tech24.vn
* haivl :)
* vnsharing
* vietsub.vnsharing.net
* veoh (video web)
* soft32.vn
* kat.cr
* comix4free
* kissanime
* kissasian.com
* kisscartoon.me
* planet-source-code
