(function() {

	function getData() {
		return [
			{ dateStr: '27/04/2014', km: 26429, note: '' },
			{ dateStr: '20/07/2014', km: 28600, note: '' },
			{ dateStr: '14/09/2014', km: 30000, note: 'Bảo dưỡng' },
			{ dateStr: '04/01/2015', km: 32200, note: 'Thay lốp, thay săm bánh sau' },
			{ dateStr: '29/03/2015', km: 34000, note: '' },
			{ dateStr: '06/08/2015', km: 36866, note: '' },
			{ dateStr: '11/12/2015', km: 39732, note: 'Thay lốp, thay săm bánh sau' },
			{ dateStr: '14/02/2016', km: 41041, note: '' },
			{ dateStr: '25/04/2016', km: 42029, note: 'Bảo dưỡng, thay ác quy' },
			{ dateStr: '30/06/2016', km: 43200, note: 'Thay nhông xích Honda bằng nhông xích Thái Lan' },
			{ dateStr: '18/09/2016', km: 45167, note: '' },
			{ dateStr: '05/12/2016', km: 47269, note: '' },
			{ dateStr: '28/02/2017', km: 49454, note: '' },
			{ dateStr: '30/04/2017', km: 50851, note: '' }
		];
	}
	
	function buildHtml(data) {
		var html = `
				<table>
					<thead>
						<tr>
							<th>Date</th>
							<th>Km</th>
							<th>Date diff</th>
							<th>Km diff</th>
							<th>Note</th>
						</tr>
					</thead>
					<tbody>`;
		for (var i = 0; i < data.length; i++) {
			var e = data[i];
			e.date = converStringToDate(e.dateStr);
			
			var dd;
			var kmDiff;
			if (i > 0) {
				dd = dateDiff(data[i - 1].date, e.date);
				kmDiff = numberWithCommas(e.km - data[i - 1].km);
			} else {
				dd = "";
				kmDiff = "";
			}
			
			html += `<tr>
					<td>${e.dateStr}</td>
					<td>${numberWithCommas(e.km)}</td>
					<td>${dd}</td>
					<td>${kmDiff}</td>
					<td>${e.note}</td>
					</tr>`;
		}
		html += `</tbody>
				</table>`;
		return html;
	}
	
	function warningNextMaintain(data) {
		var last = data[data.length - 1];
		var nextDate = addDate(last.date, 60);
		var nextKm = last.km + 2000;
		var currentDate = new Date();
		var dd = dateDiff(currentDate, nextDate);

		var html = `<p>Next date: ${convertDateToString(nextDate)} ${(dd < 10) ? "(HOT ALERT)" : ""}</p>
				<p>Next km: ${numberWithCommas(nextKm)}</p>`;
		return html;
	}
	
	function insertToCurrentPage(html) {
		var section = document.querySelector("#motorbike-oil");
		section.innerHTML = html;	
	}
	
	function init() {
		var data = getData();
		var html = buildHtml(data);
		html += warningNextMaintain(data);
		insertToCurrentPage(html);
	}
	
	init();
})();
