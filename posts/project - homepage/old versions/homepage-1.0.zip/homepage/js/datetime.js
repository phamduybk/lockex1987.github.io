/**
 * Calculate the number of days between two dates (toDate - fromDate)
 * @param fromDate Từ ngày
 * @param toDate Đến ngày
 * @return Số ngày giữa 2 ngày (ví dụ từ ngày 1/1 đến 10/1 có 9 ngày)
 */
function dateDiff(fromDate, toDate) {
	var oneDay = 24 * 60 * 60 * 1000;
	return Math.round( ( toDate.getTime() - fromDate.getTime() ) / oneDay );	
}

function addDate(fromDate, numberOfDate) {
	var oneDay = 24 * 60 * 60 * 1000;
	return new Date(fromDate.getTime() + numberOfDate * oneDay);
}

/**
 * Return a date object from a text (dd/MM/yyyy)
 * @param dateString Xâu ngày tháng
 * @retun Một đối tượng Date
 */
function converStringToDate(dateString) {
	var a = dateString.split('/');
	var month = a[1];
	var year = a[2];
	var date = a[0];
	//return new Date(year, month, date);
	return new Date(year + '-' + month + '-' + date);
}

/**
 * Date to text (dd/MM/yyyy)
 * @param date Một đối tượng Date
 * @param Một xâu dạng dd/MM/yyyy tương ứng
 */
function convertDateToString(date) {
	var year = date.getFullYear().toString();
	var month_tmp = date.getMonth() + 1;
	var month = (month_tmp < 10) ? ('0' + month_tmp) : month_tmp.toString();
	var day_temp = date.getDate();
	var date = (day_temp < 10) ? ('0' + day_temp) : day_temp.toString();
	return (date + "/" + month + "/" + year);
}

function isLeapYear(year) {
	return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
}

function daysInMonth(month, year) {
	if (month == 2) {
		return isLeapYear(year) ? 29 : 28;
	} else if (month == 4 || month == 6 || month == 9 || month == 11) {
		return 30;
	} else {
		return 31;
	}
}

/**
 * Determine the day of the week (Zeller's congruence)
 * Sunday: 0, Monday: 2,..., Saturday: 6
 */
function getWeekday(d, m, y) {
	if (m < 3) {
		y--;
	}
	var offset = [1, 4, 3, 6, 1, 4, 6, 2, 5, 0, 3, 5];
	var h = (d +
				offset[m - 1] +
				y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400)
			) % 7;
	return (h + 6) % 7;
}

function buildCalendar(month, year) {
	var result = `
	<table>
		<thread>
			<tr>
				<th colspan='7' class="month-title">${month} / ${year}</th>
			</tr>
			<tr>
				<th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
			</tr>
		</thead>
		<tbody>
			<tr>`;
	
	var start = getWeekday(1, month, year);
	var end = daysInMonth(month, year);
	var i, date;
	var count = 0;
	
	for (i = 0; i < start; i++) {
		result += "<td>&nbsp;</td>";
	}
	for (date = 1; date <= end; date++, i++) {
		result += `<td id='d-${month}-${date}'>${date}</td>`;
		if (i % 7 == 6) {
			result += "</tr><tr>";
			count++;
		}
	}
	
	if (i % 7 != 0) {
		do {
			result += "<td>&nbsp;</td>";
			i++;
		} while (i % 7 != 0);
		count++;
	}
	
	if (i < 42) {
		result += "<tr>";
		for (i = 0; i < 7; i++) {
			result += "<td>&nbsp;</td>";
		}
		result += "</tr>";
	} else {
		result += "</tr>";
	}
	
	result += "</tbody></table>";
	return result;
}

function testBuildCalendar() {
	var calendar = document.getElementById("calendar");
	/*
	for (var month = 1; month <= 12; month++) {
		calendar.innerHTML += buildCalendar(month, 2016);
	}*/
	
	//calendar.innerHTML += buildCalendar(9, 2016);
	
	var currentDate = new Date();
	var month = currentDate.getMonth() + 1;
	var year = currentDate.getFullYear();
	calendar.innerHTML += buildCalendar(month, year);
}

function displayCurrentDate() {
	var now = new Date();
	var date = now.getDate();
	var month = now.getMonth() + 1;
	var year = now.getFullYear();
	//alert(date + '/' + month + '/' + year);
	document.getElementById("d-" + month + "-" + date).className = "currentDate";
}
