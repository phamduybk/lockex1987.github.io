

var note = localStorage.getItem(STORAGE_KEY.NOTE);
var noteEditor = document.getElementById("note-editor");

if (note) {
	noteEditor.value = note;
}

noteEditor.onblur = function() {
	localStorage.setItem(STORAGE_KEY.NOTE, noteEditor.value);
	logger.success("Notes saved");
};
