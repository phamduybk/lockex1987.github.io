var logger = (function() {
	
	var contentDiv = document.querySelector(".alert-box div");
	
	function logIt(text, className) {
		contentDiv.className = className;
		contentDiv.textContent = text;
		
		$(contentDiv).fadeIn(300).delay(1500).fadeOut(400);
	}
	
	return {
		success: function(text) {
			logIt(text, 'success');
		},
		error: function(text) {
			logIt(text, 'error');
		},
		warning: function(text) {
			logIt(text, 'warning');
		}
	};
})();