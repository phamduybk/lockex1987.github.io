/**
 * Create tabs
 */
function createTabs(div, defaultOpen) {

	/**
	 * Function that called when the user click a tab header
	 */
	function openTab(evt) {
		// Reset all sections and links
		var sections = div.querySelectorAll("section");
		var i;
		for (i = 0; i < sections.length; i++) {
			sections[i].style.display = "none";
		}
		var links = div.querySelectorAll("nav a");
		for (i = 0; i < links.length; i++) {
			links[i].parentNode.className = links[i].className.replace(" active", "");
		}

		// Show the current tab, and add an "active" class to the link that opened the tab
		var currentTarget = evt.target;
		var url = currentTarget.href;
		var sectionId = url.substring(url.indexOf('#'));
		div.querySelector(sectionId).style.display = "block";
		currentTarget.parentNode.className += " active";
		return false;
	}

	/**
	 * Initialize tabs
	 */
	function init() {
		var links = div.querySelectorAll("nav a");
		for (var i = 0; i < links.length; i++) {
			links[i].onclick = openTab;
		}
		
		if (defaultOpen == undefined) {
			defaultOpen =  0;
		}
		links[defaultOpen].click();
	}
	
	init();
}
