/**
 * Create an analog clock.
 * Base on this excellent guide: http://www.w3schools.com/graphics/canvas_clock_start.asp
 * @param divEle
 * 	          The DIV element that contains the clock (canvas element)
 * @param size
 *            Clock's size
 */
function createAnalogClock(divEle, size) {
	var ctx = createCanvasElement();
	var radius = (size / 2) * 0.90;
	setInterval(drawClock, 100);

	function createCanvasElement() {
		var canvas = document.createElement("canvas");
		canvas.width = size;
		canvas.height = size;
		//canvas.style.backgroundColor = "#333";
		canvas.style.border = "1px solid #333";
		canvas.style.borderRadius = "5px";
		divEle.appendChild(canvas);
		var ctx = canvas.getContext("2d");
		ctx.translate(size / 2, size / 2);
		return ctx;
	}

	function drawClock() {
		drawFace(ctx, radius);
		drawNumbers(ctx, radius);
		drawTime(ctx, radius);
	}

	function drawFace(ctx, radius) {
		ctx.beginPath();
		ctx.arc(0, 0, radius, 0, 2 * Math.PI);
		ctx.fillStyle = 'white';
		ctx.fill();

		/*
		var grad = ctx.createRadialGradient(0, 0, radius * 0.95, 0, 0, radius * 1.05);
		grad.addColorStop(0, '#333');
		grad.addColorStop(0.5, 'white');
		grad.addColorStop(1, '#333');
		ctx.strokeStyle = grad;
		ctx.lineWidth = radius * 0.1;
		ctx.stroke();
		

		ctx.beginPath();
		ctx.arc(0, 0, radius * 0.1, 0, 2 * Math.PI);
		ctx.fillStyle = '#333';
		ctx.fill();
		*/
	}

	function drawNumbers(ctx, radius) {
		ctx.font = radius * 0.15 + "px arial";
		ctx.textBaseline = "middle";
		ctx.textAlign = "center";
		ctx.fillStyle = '#333';
		for (var num = 1; num <= 12; num++) {
			var ang = num * Math.PI / 6;
			ctx.rotate(ang);
			ctx.translate(0, -radius * 0.85);
			ctx.rotate(-ang);
			ctx.fillText(num.toString(), 0, 0);
			ctx.rotate(ang);
			ctx.translate(0, radius * 0.85);
			ctx.rotate(-ang);
		}
	}

	function drawTime(ctx, radius) {
		var now = new Date();
		var hour = now.getHours();
		var minute = now.getMinutes();
		var second = now.getSeconds();
		var milli = now.getMilliseconds();
		
		// hour
		hour = hour % 12;
		hour = (hour * Math.PI / 6)
				+ (minute * Math.PI / (6 * 60))
				+ (second * Math.PI / (6 * 3600));
		drawHand(ctx, hour, radius * 0.5, radius * 0.07, '#3498db');
		
		// minute
		minute = (minute * Math.PI / 30)
				+ (second * Math.PI / (30 * 60));
		drawHand(ctx, minute, radius * 0.6, radius * 0.05, '#000');
		
		// second
		second = (second * Math.PI / 30)
				+ (milli * Math.PI / 30000);
		drawHand(ctx, second, radius * 0.75, radius * 0.02, '#777');
	}

	function drawHand(ctx, pos, length, width, fillStyle) {
		//ctx.strokeStyle = fillStyle;

		ctx.beginPath();
		ctx.lineWidth = width;
		ctx.lineCap = "round";
		ctx.moveTo(0, 0);
		ctx.rotate(pos);
		ctx.lineTo(0, -length);
		ctx.stroke();
		ctx.rotate(-pos);
	}
}