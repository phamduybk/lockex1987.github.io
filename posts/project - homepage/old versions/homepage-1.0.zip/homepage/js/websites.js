/**
 * Display JSON objects to the page
 */
function displayHtml(websites, divId) {
	var divObj = document.getElementById(divId);
	for (var i = 0; i < websites.length; i++) {
		var w = websites[i];
		
		var li = document.createElement("li");
		w.element = li;
		
		var img = document.createElement("img");
		img.src = (w.icon) ? w.icon : "images/default.png";
		li.appendChild(img);
		
		var a = document.createElement("a");
		a.href = w.url;
		a.textContent = w.name;
		a.target = "_blank";
		li.appendChild(a);
		
		divObj.appendChild(li);
	}
}

/**
 * Get tags list
 */
function getTagList(websites) {
	var tags = {};
	for (var i = 0; i < websites.length; i++) {
		var w = websites[i];
		if (w.tags) {
			var a = w.tags.split(",");
			for (var j = 0; j < a.length; j++) {
				var s = a[j].trim();
				tags[s] = tags[s] ? tags[s] + 1 : 1;
			}
		} else {
			// Ensure the tags property is not null
			w.tags = '';
		}
	}
	return tags;
}

/**
 * Display the tag list
 */
function buildTagList(tags, divId, websites) {
	var divObj = document.getElementById(divId);
	for (var t in tags) {
		var li = document.createElement("li");
		li.id = t;
		li.textContent = t; // + " (" + tags[t] + ")";
		li.onclick = function() {
			filterByTag(this.id, websites);
		};
		divObj.appendChild(li);
	}
}

/**
 * Filter by tag
 */
function filterByTag(tag, websites) {
	for (var i = 0; i < websites.length; i++) {
		var w = websites[i];
		w.element.style.display = ( (", " + w.tags + ",").indexOf(", " + tag + ",") >= 0 ) ? "" : "none";
	}
}

/**
 * Show all websites
 */
function showAllWebsites(websites) {
	for (var i = 0; i < websites.length; i++) {
		var w = websites[i];
		w.element.style.display = "";
	}
}

(function() {
	var websites = getData();
	var tags = getTagList(websites);
	
	displayHtml(websites, "container");
	buildTagList(tags, "tag-list", websites);
	
	document.getElementById("show-all").onclick = function() {
		showAllWebsites(websites);
	};
	
	// TODO
	
	// NOTE
})();
