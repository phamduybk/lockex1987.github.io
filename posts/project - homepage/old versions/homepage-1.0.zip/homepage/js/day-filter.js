// Note: Sunday is 0, Monday is 1, and so on.
var dayFilter = (function() {
	var d = new Date();
	var n = d.getDay();
	
	function checkDay(day) {
		if (!day) {
			return true;
		} else if (day.indexOf(n) >= 0) {
			return true;
		} else {
			return false;
		}
	}
	
	return {
		checkDay: checkDay
	}
})();
 
