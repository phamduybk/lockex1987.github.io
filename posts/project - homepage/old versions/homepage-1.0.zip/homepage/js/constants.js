/**
 * Location: home or company
 * If a website has location HOME, it will only appear in home's laptop
 * If it has location COMPANY, it will only appear in company's PC
 * It will appear in both places by default
 */
const LOCATION = {
	HOME: 1,
	COMPANY: 2
};

const STORAGE_KEY = {
	NOTE: "note",
	LOCATION: "location"
};

const TODO = {
	PENDING: 1,
	IN_PROGRESS: 2,
	COMPLETED: 3
};
