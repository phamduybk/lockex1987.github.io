var app = angular.module("myShoppingList", []); 
app.controller("myCtrl", function($scope) {
		$scope.products = [ "Milk", "Bread", "Cheese" ];

		$scope.addItem = function() {
        $scope.errortext = "";
        if (!$scope.addMe) {
					return;
				}
        if ($scope.products.indexOf($scope.addMe) == -1) {
            $scope.products.push($scope.addMe);
        } else {
            $scope.errortext = "The item is already in your shopping list.";
        }
    }

    $scope.removeItem = function(x) {
        $scope.errortext = "";    
        $scope.products.splice(x, 1);
    }
});

var todos = [
	{ title: "Recharge motorbike's oild", finishDateStr: '18/09/2016', status: TODO.PENDING }
];

for (var i = 0; i < todos.length; i++) {
	var e = todos[i];
	e.finishDate = converStringToDate(e.finishDateStr);
}

todos.sort(function(a, b) {
	return a.finishDate.getTime() - b.finishDate.getTime();
});

for (var i = 0; i < todos.length; i++) {
	
}