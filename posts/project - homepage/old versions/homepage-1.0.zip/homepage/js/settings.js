var settings = (function() {
	
	var currentLocation = localStorage.getItem(STORAGE_KEY.LOCATION);
	if (!currentLocation) {
		currentLocation = LOCATION.HOME;
	}
	var cbxLocation = document.querySelector("#cbxLocation");
	var lblLocation = document.querySelector("#lblLocation");
	
	if (currentLocation == LOCATION.HOME) {
		cbxLocation.checked = true;
		lblLocation.textContent = 'Location is home';
	} else {
		cbxLocation.checked = false;
		lblLocation.textContent = 'Location is company';
	}

	cbxLocation.onchange = function() {
		if (cbxLocation.checked) {
			currentLocation = LOCATION.HOME;
			lblLocation.textContent = 'Location is home';
		} else {
			currentLocation = LOCATION.COMPANY;
			lblLocation.textContent = 'Location is company';
		}
		localStorage.setItem(STORAGE_KEY.LOCATION, currentLocation);
		logger.success("Location setting is saved");
	};
	
	function checkLocation(loc) {
		//console.log(currentLocation + " - " + loc);
		if (!currentLocation) {
			// If current location is not set, hide all websites
			return false;
		} else if (!loc) {
			// If the website's location is not set, the website is showed by default
			return true;
		} else if (currentLocation == loc) {
			// Only show websites that are equivalent to current location
			return true;
		} else {
			return false;
		}
	}
	
	return {
		checkLocation: checkLocation
	}
})();
