var gulp = require('gulp');

/*
gulp.task('default', function() {
  console.log('Hello Gulp');
});
*/

var gulp = require('gulp');
var less = require('gulp-less');
var uglify = require('gulp-uglify');
var browserSync = require('browser-sync'); // gulp-connect, gulp-livereload

var lessFiles = 'less/*.less';

gulp.task('sync', function() {
	var files = [
		'*.html',
		'css/*.css',
		'js/*.js'
	];
	var options = {
		server: {
			baseDir: '.'
		}
	};
	browserSync.init(files, options);
});

gulp.task('less', function() {
	gulp.src(lessFiles)
			.pipe(less()) // { compress: true }
			.pipe(gulp.dest('css')); // function(f) { return f.base; }
});

gulp.task('watch', function() {
	gulp.watch(lessFiles, ['less']);
});

gulp.task('uglify', function() {
	gulp.src('js/*.js')
			.pipe(uglify())
			.pipe(gulp.dest('minjs'));
});

gulp.task('default', ['sync', 'less', 'watch']);
