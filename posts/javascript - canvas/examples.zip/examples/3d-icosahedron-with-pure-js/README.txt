A Pen created at CodePen.io. You can find this one at http://codepen.io/mcdorli/pen/LkdoZo.

 3d icosahedron with pure JavaScript. Uses no WebGL or Three.js.

It can freeze your browser after 5 subdivisions.