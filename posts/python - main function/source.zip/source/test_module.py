print("In ra tu file test_module.py")

print('Gia tri bien __name__ trong test_module.py', __name__)

if __name__ == '__main__':
    print('Test module')

