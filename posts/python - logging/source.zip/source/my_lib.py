import logging

def do_something():
    logging.info('Doing something')
    logging.error('Oh loi')
