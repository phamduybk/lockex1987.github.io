using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using System.DirectoryServices;
using System.Diagnostics;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System.Media;

namespace Appbar
{
	public partial class Form1 : Form
	{
		#region dragdrop
		ArrayList paths;
		ArrayList labels;
		int num;
		int length = 70;
		int labelfloor = 3;
		int labelheight = 15;
		int labelstart = 300;
		Color[] colors = { Color.Cyan, Color.Linen, Color.LimeGreen, Color.AliceBlue, Color.Aqua, Color.White };
		SoundPlayer sp = new SoundPlayer("ding.wav");

		private void Form1_DragDrop(object sender, DragEventArgs e)
		{
			string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

			// loop through the string array, adding each filename to the ListBox
			foreach (string s in files)
			{
				paths.Add(s);
				Label l = new Label();
				l.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - labelstart - num * (length + 10), labelfloor);
				l.Name = "l" + num;
				l.TextAlign = ContentAlignment.MiddleCenter;
				//l.BackColor = colors[num % colors.Length];
				l.BackColor = bgcolor;
				l.Size = new Size(length, labelheight);
				l.TabIndex = num;
				l.Text = s.Substring(s.LastIndexOf('\\') + 1);
				l.Click += new EventHandler(this.label_Click);
				l.MouseLeave += new EventHandler(this.label_MouseLeave);
				l.MouseEnter += new EventHandler(this.label_MouseEnter);
				this.Controls.Add(l);
				labels.Add(l);
				num++;
			}
			StreamWriter sw = new StreamWriter("data.txt");
			foreach (object o in paths)
			{
				sw.WriteLine(o.ToString());
			}
			sw.Close();
		}



		// Phai co cai nay?
		// Phai co AllowDrop trong Properties, mac dinh la false.
		private void Form1_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
			{
				e.Effect = DragDropEffects.All;
			}
		}
		private void label_Click(object sender, EventArgs e)
		{
			sp.Play();
			Process.Start((string)paths[getLabelActive(sender)]);
		}

		int size = 2;
		Font font1 = new Font("Tahoma", 7, FontStyle.Regular);
		Font font2 = new Font("Tahoma", 9, FontStyle.Bold);
		Color foreColorLeave = Color.Black;
		Color foreColorEnter = Color.White;
		private void label_MouseLeave(object sender, EventArgs e)
		{
			int i = getLabelActive(sender);
			Label l = (Label)labels[i];
			l.ForeColor = foreColorLeave;
			l.Height = labelheight;
			l.Width = length;
			l.Left = Screen.PrimaryScreen.WorkingArea.Width - labelstart - i * (length + 10);
			l.Top = labelfloor;
			l.Font = font1;
		}

		private void label_MouseEnter(object sender, EventArgs e)
		{
			int i = getLabelActive(sender);
			Label l = (Label)labels[i];
			l.ForeColor = foreColorEnter;
			l.Height =labelheight + 2 * size;
			l.Width = length + 2 * size;
			l.Left = Screen.PrimaryScreen.WorkingArea.Width - labelstart - i * (length + 10) - size;
			l.Top = labelfloor - size;
			l.Font = font2;
		}

		// Xem label nao dang duoc tuong tac.
		private int getLabelActive(object sender)
		{
			String s = sender.ToString();
			s = s.Substring(s.LastIndexOf(':') + 2);
			int i = 0;
			foreach (object o in paths)
			{
				String r = o.ToString();
				r = r.Substring(r.LastIndexOf('\\') + 1);
				if (s == r)
				{
					break;
				}
				i++;
			}
			return i;
		}

		#endregion

		public Form1()
		{
			InitializeComponent();
		}


		// Cac cau truc du lieu.
		[StructLayout(LayoutKind.Sequential)]
		struct RECT
		{
			public int left;
			public int top;
			public int right;
			public int bottom;
		}

		[StructLayout(LayoutKind.Sequential)]
		struct APPBARDATA
		{
			public int cbSize;
			public IntPtr hWnd;
			public int uCallbackMessage;
			public int uEdge;
			public RECT rc;
			public IntPtr lParam;
		}

		// Cac khai bao.
		enum ABMsg : int
		{
			ABM_NEW = 0,
			ABM_REMOVE,
			ABM_QUERYPOS,
			ABM_SETPOS,
			ABM_GETSTATE,
			ABM_GETTASKBARPOS,
			ABM_ACTIVATE,
			ABM_GETAUTOHIDEBAR,
			ABM_SETAUTOHIDEBAR,
			ABM_WINDOWPOSCHANGED,
			ABM_SETSTATE
		}
		enum ABNotify : int
		{
			ABN_STATECHANGE = 0,
			ABN_POSCHANGED,
			ABN_FULLSCREENAPP,
			ABN_WINDOWARRANGE
		}
		enum ABEdge : int
		{
			ABE_LEFT = 0,
			ABE_TOP,
			ABE_RIGHT,
			ABE_BOTTOM
		}

		// Cac ham su dung.
		[DllImport("SHELL32", CallingConvention = CallingConvention.StdCall)]
		static extern uint SHAppBarMessage(int dwMessage, ref APPBARDATA pData);
		[DllImport("USER32")]
		static extern int GetSystemMetrics(int Index);
		[DllImport("User32.dll", ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
		private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int cx, int cy, bool repaint);
		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		private static extern int RegisterWindowMessage(string msg);

		private int uCallBack;
		public void setAppbar(bool fBarRegistered)
		{
			APPBARDATA abd = new APPBARDATA();
			abd.cbSize = Marshal.SizeOf(abd);
			abd.hWnd = this.Handle;
			if (fBarRegistered)
			{
				uCallBack = RegisterWindowMessage("AppBarMessage");
				abd.uCallbackMessage = uCallBack;
				uint ret = SHAppBarMessage((int)ABMsg.ABM_NEW, ref abd);
				ABSetPos();
			}
			else
			{
				SHAppBarMessage((int)ABMsg.ABM_REMOVE, ref abd);
			}
		}

		private void ABSetPos()
		{
			APPBARDATA abd = new APPBARDATA();
			abd.cbSize = Marshal.SizeOf(abd);
			abd.hWnd = this.Handle;
			
			abd.uEdge = (int)ABEdge.ABE_TOP;

			if (abd.uEdge == (int)ABEdge.ABE_LEFT || abd.uEdge == (int)ABEdge.ABE_RIGHT)
			{
				abd.rc.top = 0;
				abd.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
				if (abd.uEdge == (int)ABEdge.ABE_LEFT)
				{
					abd.rc.left = 0;
					abd.rc.right = this.Size.Width;
				}
				else
				{
					abd.rc.right = SystemInformation.PrimaryMonitorSize.Width;
					abd.rc.left = abd.rc.right - this.Size.Width;
				}

			}
			else
			{
				abd.rc.left = 0;
				abd.rc.right = SystemInformation.PrimaryMonitorSize.Width;
				if (abd.uEdge == (int)ABEdge.ABE_TOP)
				{
					abd.rc.top = 0;
					abd.rc.bottom = this.Size.Height;
				}
				else
				{
					abd.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
					abd.rc.top = abd.rc.bottom - this.Size.Height;
				}
			}

			// Query the system for an approved size and position. 
			SHAppBarMessage((int)ABMsg.ABM_QUERYPOS, ref abd);

			// Adjust the rectangle, depending on the edge to which the 
			// appbar is anchored. 
			switch (abd.uEdge)
			{
				case (int)ABEdge.ABE_LEFT:
					abd.rc.right = abd.rc.left + this.Size.Width;
					break;
				case (int)ABEdge.ABE_RIGHT:
					abd.rc.left = abd.rc.right - this.Size.Width;
					break;
				case (int)ABEdge.ABE_TOP:
					abd.rc.bottom = abd.rc.top + this.Size.Height;
					break;
				case (int)ABEdge.ABE_BOTTOM:
					abd.rc.top = abd.rc.bottom - this.Size.Height;
					break;
			}

			// Pass the final bounding rectangle to the system. 
			SHAppBarMessage((int)ABMsg.ABM_SETPOS, ref abd);

			// Move and size the appbar so that it conforms to the 
			// bounding rectangle passed to the system. 
			MoveWindow(abd.hWnd, abd.rc.left, abd.rc.top,
				abd.rc.right - abd.rc.left, abd.rc.bottom - abd.rc.top, true);
		}

		Color bgcolor = Color.FromArgb(105, 80, 60);
		private void Form1_Load(object sender, EventArgs e)
		{
			paths = new ArrayList();
			labels = new ArrayList();
			StreamReader rs = new StreamReader("data.txt");
			String s;
			int i = 0;
			while ((s = rs.ReadLine()) != null)
			{
				paths.Add(s);
				Label l = new Label();
				l.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - labelstart - i * (length + 10), labelfloor);
				l.Name = "l" + i;
				l.Size = new Size(length, labelheight);
				l.TextAlign = ContentAlignment.MiddleCenter;
				//l.BackColor = colors[i % colors.Length];
				l.BackColor = bgcolor;
				//l.ForeColor = Color.Yellow;
				l.TabIndex = i;
				l.Text = s.Substring(s.LastIndexOf('\\') + 1);
				l.Click += new EventHandler(this.label_Click);
				l.MouseLeave += new EventHandler(this.label_MouseLeave);
				l.MouseEnter += new EventHandler(this.label_MouseEnter);
				l.Font = font1;
				this.Controls.Add(l);
				labels.Add(l);
				i++;
			}
			num = i;
			rs.Close();

			label1.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 130, 0);
			label1.Text = DateTime.Now.DayOfWeek + " " + DateTime.Now.Day + " - " + DateTime.Now.Month;
			label2.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - label1.Width - 1 - 29);
			label3.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - label1.Width - 80);
			StreamReader sr = new StreamReader("text.txt");
			message = sr.ReadLine();
			sr.Close();
			setAppbar(true);
			timer1.Start();

			this.BackColor = bgcolor;

			Graphics g = Graphics.FromHwnd(this.Handle);
			pictureBox1.Width = (int)g.MeasureString(message, font).Width;
			g.Dispose();

			initStartTime();
			resetTime();
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			setAppbar(false);
		}

		#region
		// Can cho nay de cho no mat cai border.
		protected override void WndProc(ref System.Windows.Forms.Message m)
		{
			if (m.Msg == uCallBack)
			{
				switch (m.WParam.ToInt32())
				{
					case (int)ABNotify.ABN_POSCHANGED:
						ABSetPos();
						break;
				}
			}

			base.WndProc(ref m);
		}

		protected override System.Windows.Forms.CreateParams CreateParams
		{
			get
			{
				CreateParams cp = base.CreateParams;
				cp.Style &= (~0x00C00000); // WS_CAPTION
				cp.Style &= (~0x00800000); // WS_BORDER
				cp.ExStyle = 0x00000080 | 0x00000008; // WS_EX_TOOLWINDOW | WS_EX_TOPMOST
				return cp;
			}
		}
		#endregion

		//
		
		String message;
		

		int clip = 0;
		int time = 100;
		private void timer1_Tick(object sender, EventArgs e)
		{
			timer1.Stop();
			clip = (clip >= pictureBox1.Width) ? -5 : (clip + 3);
			//start = (start > pictureBox1.Width) ? -100 : (start + 5);
			pictureBox1.Invalidate();
			timer1.Interval = time;
			timer1.Start();
		}

		Font font = new Font("Tahoma", 10, FontStyle.Bold);
		private void pictureBox1_Paint(object sender, PaintEventArgs e)
		{
			// Lay doi tuong Graphics.
			Graphics g = e.Graphics;

			// Draw text.
			int floor = 3;
			//int space = 8;
			float start = 10;
			Font f2 = new Font("Courier", 12, FontStyle.Italic | FontStyle.Bold);
			g.DrawString(message, font, Brushes.White, start, floor);
			g.FillRectangle(Brushes.Yellow, new Rectangle(clip, 0, 10, pictureBox1.Height));
			g.SetClip(new Rectangle(clip, 0, 10, pictureBox1.Height));
			g.DrawString(message, font, Brushes.Black, start, floor);			
		}

		int second = 0;
		int minute = 0;
		int hour = 0;
		private void timer2_Tick(object sender, EventArgs e)
		{
			second++;
			if (second == 60)
			{
				second = 0;
				minute++;
				if (minute == 60)
				{
					//minute = 0;
					//hour++;
					resetTime();
				}
				label3.Text = hour + " : " + minute + " : ";
			}
			label2.Text = ((second < 10) ? "0" : "") + second;
		}

		private void resetTime()
		{
			long tick = DateTime.Now.Ticks - startTime.Ticks;
			TimeSpan span = new TimeSpan(tick);
			hour = span.Hours;
			minute = span.Minutes;
			second = span.Seconds;
			label2.Text = ((second < 10) ? "0" : "") + second;
			label3.Text = hour + " : " + minute + " : ";
		}

		DateTime startTime;
		private void initStartTime()
		{
			DirectoryEntry dirs = new DirectoryEntry("WinNT://" + Environment.MachineName);
			foreach (DirectoryEntry de in dirs.Children)
			{
				if ((de.SchemaClassName == "User") && (de.Name.ToString() == Environment.UserName.ToString()))
				{
					startTime = DateTime.Parse(de.Properties["lastlogin"].Value.ToString());
				}
			}
		}
	}
}