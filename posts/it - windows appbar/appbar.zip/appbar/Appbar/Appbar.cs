using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Runtime.InteropServices;

namespace Appbar
{
	class AppbarForm : Form
	{
		public AppbarForm()
		{
		}

		// Cac cau truc du lieu.
		[StructLayout(LayoutKind.Sequential)]
		struct RECT
		{
			public int left;
			public int top;
			public int right;
			public int bottom;
		}

		[StructLayout(LayoutKind.Sequential)]
		struct APPBARDATA
		{
			public int cbSize;
			public IntPtr hWnd;
			public int uCallbackMessage;
			public int uEdge;
			public RECT rc;
			public IntPtr lParam;
		}

		// Cac khai bao.
		enum ABMsg : int
		{
			ABM_NEW = 0,
			ABM_REMOVE,
			ABM_QUERYPOS,
			ABM_SETPOS,
			ABM_GETSTATE,
			ABM_GETTASKBARPOS,
			ABM_ACTIVATE,
			ABM_GETAUTOHIDEBAR,
			ABM_SETAUTOHIDEBAR,
			ABM_WINDOWPOSCHANGED,
			ABM_SETSTATE
		}
		enum ABNotify : int
		{
			ABN_STATECHANGE = 0,
			ABN_POSCHANGED,
			ABN_FULLSCREENAPP,
			ABN_WINDOWARRANGE
		}
		enum ABEdge : int
		{
			ABE_LEFT = 0,
			ABE_TOP,
			ABE_RIGHT,
			ABE_BOTTOM
		}

		// Cac ham su dung.
		[DllImport("SHELL32", CallingConvention = CallingConvention.StdCall)]
		static extern uint SHAppBarMessage(int dwMessage, ref APPBARDATA pData);
		[DllImport("USER32")]
		static extern int GetSystemMetrics(int Index);
		[DllImport("User32.dll", ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
		private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int cx, int cy, bool repaint);
		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		private static extern int RegisterWindowMessage(string msg);

		private int uCallBack;
		public void setAppbar(bool fBarRegistered)
		{
			APPBARDATA abd = new APPBARDATA();
			abd.cbSize = Marshal.SizeOf(abd);
			abd.hWnd = this.Handle;
			if (fBarRegistered)
			{
				uCallBack = RegisterWindowMessage("AppBarMessage");
				abd.uCallbackMessage = uCallBack;
				uint ret = SHAppBarMessage((int)ABMsg.ABM_NEW, ref abd);
				ABSetPos();
			}
			else
			{
				SHAppBarMessage((int)ABMsg.ABM_REMOVE, ref abd);
			}
		}

		private void ABSetPos()
		{
			APPBARDATA abd = new APPBARDATA();
			abd.cbSize = Marshal.SizeOf(abd);
			abd.hWnd = this.Handle;
			
			abd.uEdge = (int)ABEdge.ABE_TOP;

			if (abd.uEdge == (int)ABEdge.ABE_LEFT || abd.uEdge == (int)ABEdge.ABE_RIGHT)
			{
				abd.rc.top = 0;
				abd.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
				if (abd.uEdge == (int)ABEdge.ABE_LEFT)
				{
					abd.rc.left = 0;
					abd.rc.right = this.Size.Width;
				}
				else
				{
					abd.rc.right = SystemInformation.PrimaryMonitorSize.Width;
					abd.rc.left = abd.rc.right - this.Size.Width;
				}

			}
			else
			{
				abd.rc.left = 0;
				abd.rc.right = SystemInformation.PrimaryMonitorSize.Width;
				if (abd.uEdge == (int)ABEdge.ABE_TOP)
				{
					abd.rc.top = 0;
					abd.rc.bottom = this.Size.Height;
				}
				else
				{
					abd.rc.bottom = SystemInformation.PrimaryMonitorSize.Height;
					abd.rc.top = abd.rc.bottom - this.Size.Height;
				}
			}

			// Query the system for an approved size and position. 
			SHAppBarMessage((int)ABMsg.ABM_QUERYPOS, ref abd);

			// Adjust the rectangle, depending on the edge to which the 
			// appbar is anchored. 
			switch (abd.uEdge)
			{
				case (int)ABEdge.ABE_LEFT:
					abd.rc.right = abd.rc.left + this.Size.Width;
					break;
				case (int)ABEdge.ABE_RIGHT:
					abd.rc.left = abd.rc.right - this.Size.Width;
					break;
				case (int)ABEdge.ABE_TOP:
					abd.rc.bottom = abd.rc.top + this.Size.Height;
					break;
				case (int)ABEdge.ABE_BOTTOM:
					abd.rc.top = abd.rc.bottom - this.Size.Height;
					break;
			}

			// Pass the final bounding rectangle to the system. 
			SHAppBarMessage((int)ABMsg.ABM_SETPOS, ref abd);

			// Move and size the appbar so that it conforms to the 
			// bounding rectangle passed to the system. 
			MoveWindow(abd.hWnd, abd.rc.left, abd.rc.top,
				abd.rc.right - abd.rc.left, abd.rc.bottom - abd.rc.top, true);
		}

		#region
		// Can cho nay de cho no mat cai border.
		protected override void WndProc(ref System.Windows.Forms.Message m)
		{
			if (m.Msg == uCallBack)
			{
				switch (m.WParam.ToInt32())
				{
					case (int)ABNotify.ABN_POSCHANGED:
						ABSetPos();
						break;
				}
			}

			base.WndProc(ref m);
		}

		protected override System.Windows.Forms.CreateParams CreateParams
		{
			get
			{
				CreateParams cp = base.CreateParams;
				cp.Style &= (~0x00C00000); // WS_CAPTION
				cp.Style &= (~0x00800000); // WS_BORDER
				cp.ExStyle = 0x00000080 | 0x00000008; // WS_EX_TOOLWINDOW | WS_EX_TOPMOST
				return cp;
			}
		}
		#endregion
	}
}
