<?php
$page_url = "firt_page.php";
$page_title = "First page";
$page_content = "<p>This is the content of <strong>first_page.php</strong>.</p>";

include "base.php";
?>