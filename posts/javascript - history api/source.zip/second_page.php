<?php
$page_url = "second_page.php";
$page_title = "Second page";
$page_content = "<p>This is the content of <strong>second_page.php</strong>.</p>";

include "base.php";
?>