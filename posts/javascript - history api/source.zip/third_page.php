<?php
$page_url = "third_page.php";
$page_title = "Third page";
$page_content = "<p>This is the content of <strong>third_page.php</strong>.</p>";

include "base.php";
?>